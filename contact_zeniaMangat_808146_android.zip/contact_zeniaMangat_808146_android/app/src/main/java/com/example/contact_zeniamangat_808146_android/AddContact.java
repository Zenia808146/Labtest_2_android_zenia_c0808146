package com.example.contact_zeniamangat_808146_android;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddContact extends AppCompatActivity {
private EditText firstname,lastname,email,number,address;
private Button insertButton;
Sqlitehelperclass sqlitehelperclass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contact);
        connectxml();
        sqlitehelperclass = new Sqlitehelperclass(getApplicationContext());
       insertButton.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               String firstNameText = firstname.getText().toString().trim();
               String lastNameText = lastname.getText().toString().trim();
               String emailText = email.getText().toString().trim();
               String numberText = number.getText().toString().trim();
               String addressText = address.getText().toString().trim();

               if(TextUtils.isEmpty(firstNameText))
               {
                   firstname.setError("empty firstname");
                   return;
               }else if(TextUtils.isEmpty(lastNameText)){
                   lastname.setError("empty lastname");
                   return;
               }else if(TextUtils.isEmpty(emailText))
               {
                   email.setError("empty email");
                   return;
               }else if(TextUtils.isEmpty(numberText))
               {
                   number.setError(" empty Number");
                   return;
               }else if(TextUtils.isEmpty(addressText))
               {
                   address.setError("address empty");
               }else
               {
                   insertdata(firstNameText,lastNameText,emailText,numberText,addressText);
               }

           }
       });
    }

    private void insertdata(String firstNameText, String lastNameText, String emailText, String numberText, String addressText) {
   boolean result = sqlitehelperclass.insert(firstNameText,lastNameText,emailText,numberText,addressText);
   if(result)
   {
       Toast.makeText(this, "Value inserted", Toast.LENGTH_SHORT).show();
   }else
   {
       Toast.makeText(this, "Insertion failed", Toast.LENGTH_SHORT).show();
   }

    }

    private void connectxml() {
        firstname = findViewById(R.id.firstname_edit);
        lastname = findViewById(R.id.lastname_edit);
        email = findViewById(R.id.email_edit);
        number = findViewById(R.id.number_edit);
        address = findViewById(R.id.address_edit);
        insertButton = findViewById(R.id.insertbtn);
    }
}