package com.example.contact_zeniamangat_808146_android;

import java.io.Serializable;

public class ContactModel implements Serializable {
    private String firstname;
    private String lastname;
    private String email;
    private String number;
    private String address;
    private String id;

    public ContactModel(String firstname, String lastname, String email, String number, String address, String id) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.email = email;
        this.number = number;
        this.address = address;
        this.id = id;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public ContactModel() {
    }
}
