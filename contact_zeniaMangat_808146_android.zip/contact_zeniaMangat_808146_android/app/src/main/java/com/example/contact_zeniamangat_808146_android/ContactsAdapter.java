package com.example.contact_zeniamangat_808146_android;

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.Serializable;
import java.util.ArrayList;

public class ContactsAdapter extends ArrayAdapter<ContactModel> {
    ArrayList<ContactModel> contactlist;
    Context context;
    public ContactsAdapter(@NonNull Context context, int resource,ArrayList<ContactModel> contactlist) {
        super(context, resource);
        this.contactlist = contactlist;
        this.context = context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater =(LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.listformat,null);
        TextView textView = view.findViewById(R.id.contact_name);
        ContactModel contactModel = contactlist.get(position);
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Intent intent =new Intent(context,UserDetail.class);
               intent.putExtra("id",contactModel.getId());
               intent.putExtra("firstname",contactModel.getFirstname());
               intent.putExtra("lastname",contactModel.getLastname());
               intent.putExtra("email",contactModel.getEmail());
               intent.putExtra("number",contactModel.getNumber());
               intent.putExtra("address",contactModel.getAddress());
               intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
               context.startActivity(intent);
            }
        });
        textView.setText(contactModel.getFirstname() + " "+ contactModel.getLastname());
        return view;
    }

    @Override
    public int getCount() {
        return contactlist.size();
    }
}
