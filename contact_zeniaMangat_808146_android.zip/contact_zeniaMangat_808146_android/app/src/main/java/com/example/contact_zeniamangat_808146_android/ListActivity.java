package com.example.contact_zeniamangat_808146_android;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class ListActivity extends AppCompatActivity {
ListView listView;
Sqlitehelperclass sqlitehelperclass;
ArrayList<ContactModel> arrayList;
TextView textView ;
EditText editText;
Button searchbtn;
    private static final String TAG = "ListActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        listView = findViewById(R.id.listview);
        textView = findViewById(R.id.totalitemtext);
       editText = findViewById(R.id.searchitem);
       
       searchbtn = findViewById(R.id.searchbtn);
        sqlitehelperclass = new Sqlitehelperclass(getApplicationContext());
        arrayList = new ArrayList<>();
searchbtn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if(arrayList != null)
        {
            arrayList.clear();
        }
        String searchtext = editText.getText().toString().trim();
Cursor cursor = sqlitehelperclass.getfilterdata(searchtext);
        while (cursor.moveToNext())
        {
            ContactModel contactModel = new ContactModel();
            contactModel.setId(cursor.getString(0));
            contactModel.setFirstname(cursor.getString(1));
            contactModel.setLastname(cursor.getString(2));
            contactModel.setEmail(cursor.getString(3));
            contactModel.setNumber(cursor.getString(4));
            contactModel.setAddress(cursor.getString(5));
            arrayList.add(contactModel);
        }
        ContactsAdapter contactsAdapter = new ContactsAdapter(getApplicationContext(),R.layout.listformat,arrayList);
        listView.setAdapter(contactsAdapter);
    }
});


    }

    @Override
    protected void onStart() {

        super.onStart();
        Cursor cursor =  sqlitehelperclass.getData();
        int idcount = cursor.getCount();
       textView.setText("Availble Contacts "+idcount);
        while (cursor.moveToNext())
        {
            ContactModel contactModel = new ContactModel();
            contactModel.setId(cursor.getString(0));
            contactModel.setFirstname(cursor.getString(1));
            contactModel.setLastname(cursor.getString(2));
            contactModel.setEmail(cursor.getString(3));
            contactModel.setNumber(cursor.getString(4));
            contactModel.setAddress(cursor.getString(5));
            arrayList.add(contactModel);
        }
        ContactsAdapter contactsAdapter = new ContactsAdapter(getApplicationContext(),R.layout.listformat,arrayList);
        listView.setAdapter(contactsAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.contactaddoptions,menu);
        return true;
    }

    @Override
    protected void onPause() {

        super.onPause();
        arrayList.clear();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if(id == R.id.contactadd)
        {
startActivity(new Intent(ListActivity.this,AddContact.class));
        }
        return true;
    }



}