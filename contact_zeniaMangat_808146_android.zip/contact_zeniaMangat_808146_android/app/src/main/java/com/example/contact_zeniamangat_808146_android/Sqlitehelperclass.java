package com.example.contact_zeniamangat_808146_android;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Sqlitehelperclass extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "contacts.db";
    public static final String TABLE_NAME="contact";
    public static final String FIRST_NAME = "firstname";
    public static final String LAST_NAME = "lastname";
    public static final String ID ="id";
    public static final String NUMBER ="number";
    public static final String EMAIL = "email";
    public static final String ADDRESS="address";
    public Sqlitehelperclass(@Nullable Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "create table "+TABLE_NAME+ " (id integer primary key AutoIncrement, firstname text,lastname text,email text,number text,address text)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS contacts");
        onCreate(db);
    }

    public boolean insert(String firstname,String lastname,String email,String number,String address)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("firstname", firstname);
        contentValues.put("lastname", lastname);
        contentValues.put("number",number);
        contentValues.put("email",email);
        contentValues.put("address", address);

        long res = db.insert(TABLE_NAME, null, contentValues);
        if(res <0)
        {
            return false;
        }else
        {
            return true;
        }
    }
    public Cursor getData() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from "+TABLE_NAME, null );
        return res;
    }
    public boolean updateContact( String id, String firstname,String lastname,String email,String number, String address) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(FIRST_NAME, firstname);
        contentValues.put(LAST_NAME, lastname);
        contentValues.put(EMAIL,email);
        contentValues.put(NUMBER,number);
        contentValues.put(ADDRESS, address);

        int result =db.update(TABLE_NAME, contentValues, "id = ? ", new String[] { id } );
        if(result<0)
        {
            return false;
        }else
        {
            return true;
        }

    }
    public int deleteContact (String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME,
                "id = ? ",
                new String[] { id });
    }
    public Cursor getfilterdata(String pattern)
    {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select * from "+TABLE_NAME+" where firstname like '"+pattern+"%'",null);
        return cursor;
    }
}
