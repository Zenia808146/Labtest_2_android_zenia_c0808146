package com.example.contact_zeniamangat_808146_android;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.telecom.TelecomManager;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UserDetail extends AppCompatActivity {
  private   String idText,emailText,firstnameText,lastnameText,numberText,addressText;
    private EditText firstname,lastname,email,number,address,msgtedit;
    private Button deletebtn,updatebtn,callbtn,msgbtn,emailbtn,sendbtn;
    Sqlitehelperclass sqlitehelperclass;
    String[] permissions = {Manifest.permission.CALL_PHONE,Manifest.permission.SEND_SMS};
    int CALL_REQUEST = 12;
    int SMS_REQUEST= 56;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_detail);
          connectxml();
          getdata();
          setdata();
          sqlitehelperclass = new Sqlitehelperclass(getApplicationContext());
          updatebtn.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {
                 firstnameText = firstname.getText().toString().trim();
                 lastnameText = lastname.getText().toString().trim();
                 emailText = email.getText().toString().trim();
                 numberText = number.getText().toString().trim();
                 addressText = address.getText().toString().trim();
                 boolean result =sqlitehelperclass.updateContact(idText,firstnameText,lastnameText,emailText,numberText,addressText);
             if(result)
             {
                 Toast.makeText(UserDetail.this, "value updated", Toast.LENGTH_SHORT).show();
                Cursor cursor =  sqlitehelperclass.getData();
                 while (cursor.moveToNext())
                 {
                     if(cursor.getString(0).equals(idText))
                     {
                         firstname.setText(cursor.getString(1));
                         lastname.setText(cursor.getString(2));
                         email.setText(cursor.getString(3));
                         number.setText(cursor.getString(4));
                         address.setText(cursor.getString(5));
                     }

                 }
             }else
             {
                 Toast.makeText(UserDetail.this, "value updation failed", Toast.LENGTH_SHORT).show();
             }


              }
          });
deletebtn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
      int result =   sqlitehelperclass.deleteContact(idText);
      if(result<0)
      {
          Toast.makeText(UserDetail.this, "value deletion failed", Toast.LENGTH_SHORT).show();
      }else
      {
          Toast.makeText(UserDetail.this, "value deleted ", Toast.LENGTH_SHORT).show();
      }
    }
});
callbtn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if(ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED){
            requestPermissions(permissions,CALL_REQUEST);
        }else{
            TelecomManager telecomManager =(TelecomManager) getApplicationContext().getSystemService(Context.TELECOM_SERVICE);
       Intent intent = new Intent(Intent.ACTION_CALL);
       intent.setData(Uri.parse("tel:"+numberText));
       intent.putExtra("simSlot",1);
       startActivity(intent);


        }

    }
});

emailbtn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Intent emailintent = new Intent(Intent.ACTION_SEND);
        emailintent.putExtra(Intent.EXTRA_EMAIL,new String[]{emailText});
        emailintent.setType("message/rfc822");

        startActivity(Intent.createChooser(emailintent,"Choose an email Client : "));
    }
});
msgbtn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        sendbtn.setVisibility(View.VISIBLE);
        msgtedit.setVisibility(View.VISIBLE);
        msgbtn.setEnabled(false);
    }
});

sendbtn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(permissions, CALL_REQUEST);
        } else {
            String msgtext = msgtedit.getText().toString().trim();
            msgtedit.setVisibility(View.GONE);
            msgbtn.setEnabled(true);
            sendbtn.setVisibility(View.GONE);
            Intent smsintent = new Intent(getApplicationContext(), ListActivity.class);

            PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), SMS_REQUEST, smsintent, 0);
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(numberText, null, msgtext, pendingIntent, null);
            Toast.makeText(UserDetail.this, "Msg Send Successfully", Toast.LENGTH_SHORT).show();
        }
    }
});

    }

    private void setdata() {
firstname.setText(firstnameText);
lastname.setText(lastnameText);
email.setText(emailText);
number.setText(numberText);
address.setText(addressText);

    }

    private void getdata() {
if(getIntent() != null)
{
    idText = getIntent().getStringExtra("id");
    firstnameText = getIntent().getStringExtra("firstname");
    lastnameText = getIntent().getStringExtra("lastname");
    emailText = getIntent().getStringExtra("email");
    numberText = getIntent().getStringExtra("number");
    addressText  = getIntent().getStringExtra("address");
}
    }

    private void connectxml() {
        firstname = findViewById(R.id.firstname_detail);
        lastname = findViewById(R.id.lastname_detail);
        email = findViewById(R.id.email_detail);
        number = findViewById(R.id.number_detail);
        address = findViewById(R.id.address_detail);
        deletebtn = findViewById(R.id.deletebtn);
        updatebtn = findViewById(R.id.updatebtn);
        callbtn = findViewById(R.id.callbtn);
        msgbtn = findViewById(R.id.msgbtn);
        emailbtn = findViewById(R.id.emailbtn);
        msgtedit = findViewById(R.id.messsage_detail);
        sendbtn = findViewById(R.id.sendbtn);

    }
}